package com.itwill.shop.dao;

public class ProductSQL {
	public final static String PRODUCT_LIST=
			"select * from product";
	public final static String PRODUCT_SELECT_BY_NO=
			"select * from product where p_no=?";
	
	
}
